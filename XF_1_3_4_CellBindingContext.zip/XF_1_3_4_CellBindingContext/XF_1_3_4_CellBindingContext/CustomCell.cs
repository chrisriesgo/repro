﻿using System;
using Xamarin.Forms;

namespace XF_1_3_4_CellBindingContext
{
	public class CustomCell : ViewCell
	{
		public Label DescriptionLabel { get; set; }
		public Image Icon { get; set; }
		public TapGestureRecognizer TapRecognizer { get; set; }

		public CustomCell()
		{
			DescriptionLabel = new Label 
			{
				TextColor = Color.Black,
				FontSize = 14
			};

			DescriptionLabel.SetBinding(Label.TextProperty,
				new Binding("."));

			Icon = new Image 
			{
				BackgroundColor = Color.Red,
				WidthRequest = 30,
				HeightRequest = 30,
				VerticalOptions = LayoutOptions.Start,
				HorizontalOptions = LayoutOptions.End
			};

			View = new StackLayout {
				Orientation = StackOrientation.Vertical,
				HorizontalOptions = LayoutOptions.StartAndExpand,
				Children = {
					Icon,
					DescriptionLabel
				}
			};

			TapRecognizer = new TapGestureRecognizer();
			TapRecognizer.NumberOfTapsRequired = 1;
			TapRecognizer.Tapped += IconTapped;

			Icon.GestureRecognizers.Add(TapRecognizer);
		}

		protected override void OnAppearing()
		{
			base.OnAppearing();
			var msg = BindingContext as string;
			Console.WriteLine("OnAppearing Row is: " + msg);
		}

		protected override void OnDisappearing()
		{
			base.OnDisappearing();
		}

		void IconTapped(object sender, EventArgs e)
		{
			var msg = BindingContext as string;
			Console.WriteLine(String.Format("\nBindingContext Cell '{0}'", msg));
		}
	}
}

