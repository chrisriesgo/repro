﻿using System;
using Xamarin.Forms;
using System.Collections.Generic;

namespace XF_1_3_4_CellBindingContext
{
	public class MainPage : ContentPage
	{
		public MainPage()
		{
			BindingContext = new ViewModel();

			var list = new ListView {
				HasUnevenRows = true,
				VerticalOptions = LayoutOptions.FillAndExpand,
				RowHeight = -1,
				ItemTemplate = new DataTemplate(typeof(CustomCell))
			};

			list.SetBinding<ViewModel>(ItemsView<Cell>.ItemsSourceProperty, vm => vm.Items);

			Content = list;
		}
	}

	public class ViewModel// : ObservableBase
	{
		public ViewModel()
		{
			Items = new List<string>();
			for(var i = 1; i <= 100; i++)
			{
				Items.Add(i.ToString());
			}
		}

		private List<string> _items;
		public List<string> Items { get; set; }
//		public List<string> Items
//		{
//			get
//			{
//				return _items;
//			}
//			set
//			{
//				SetField(ref _items, value);
//			}
//		}
	}
}

